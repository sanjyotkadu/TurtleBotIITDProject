/*
 * Kiwi Holonomic Drive — Duttallbot / TurtleBot IITD
 * ---------------------------------------------------------------------
 * Combines:
 *   - robot_config.h   (pins, channel map, tuning constants — untouched)
 *   - IBusReader.h      (iBUS protocol parser — untouched)
 *   - Joystick reading  (same logic as joystick_read.ino)
 *   - 3-wheel kiwi kinematics (from user-provided pseudocode, renamed
 *     to match this project's Vx/Vy/Omega convention)
 *
 * STICK MAPPING (per robot_config.h, verified on this transmitter):
 *   RIGHT stick L/R (CH4, IBUS_CH_VX)    -> Vx     (strafe)
 *   RIGHT stick U/D (CH2, IBUS_CH_VY)    -> Vy     (forward/back)
 *   LEFT  stick L/R (CH1, IBUS_CH_OMEGA) -> Omega  (rotation)
 *
 * KINEMATICS (3-wheel kiwi, 120 deg apart):
 *   wheel_speed = -Vx*sin(theta) + Vy*cos(theta) + Omega
 *   Matching wheel angles from robot_config.h (A=210, B=330, C=90):
 *     Motor C (90 deg,  front)      = -Vx + Omega
 *     Motor A (210 deg, back-left)  = 0.5*Vx - (sqrt(3)/2)*Vy + Omega
 *     Motor B (330 deg, back-right) = 0.5*Vx + (sqrt(3)/2)*Vy + Omega
 *   This is exactly the formula in the pasted pseudocode:
 *     motorOnePower   (-> Motor C) = -Vx            ... + Omega
 *     motorTwoPower   (-> Motor A) =  Vx/2 - Vy*sqrt(3)/2  ... + Omega
 *     motorThreePower (-> Motor B) =  Vx/2 + Vy*sqrt(3)/2  ... + Omega
 *
 * BUG FIX vs pasted pseudocode: original code only called SetPower()
 * inside the "if any |power|>1" block, so motors never moved unless
 * saturated. Fixed here: normalize only when needed, but always drive.
 *
 * DIRECTION CORRECTION: robot_config.h's DIR_A_CW / DIR_B_CW / DIR_C_CW
 * (currently all -1, from your physical CW rotation test) are applied
 * as a final sign flip so a positive kinematic command always drives
 * the wheel the direction the maths expects, regardless of wiring polarity.
 */

#include "robot_config.h"
#include "IBusReader.h"
#include <math.h>

IBusReader ibus(IBUS_SERIAL);

#define IBUS_CH_LEFT_UD  2   // CH3, left stick U/D — unused axis, read for reference only

const float SQRT3_OVER_2 = 0.8660254f;

// Calibrated resting centers, captured at boot. Spring-centered sticks
// (especially rudder-type, like your rotation axis) often don't return
// to exactly 1500us — calibrating removes that drift instead of just
// widening the deadzone, which would cost you low-speed precision.
int centerVX    = IBUS_PWM_MID;
int centerVY    = IBUS_PWM_MID;
int centerOmega = IBUS_PWM_MID;

// Clamp a calibrated center to a plausible band around the nominal mid.
// A real centered stick rests within a couple hundred us of 1500; a value
// wildly outside that (like the 24/35/481 a bad calibration can produce)
// is garbage and would leave a huge offset at rest, so fall back to 1500.
int sanitizeCenter(int c) {
  if (c < IBUS_PWM_MID - 250 || c > IBUS_PWM_MID + 250) return IBUS_PWM_MID;
  return c;
}

void calibrateCenters() {
  // Wait for a valid RC link BEFORE sampling, so we learn the true
  // resting position instead of the default 1500. Without this, if the
  // link wasn't fully up during the boot window the centers stayed at
  // 1500, and a non-1500 rest (e.g. ~1870) showed up as a constant
  // offset -- that was the 0.74 you saw at startup. Give up after 6s.
  Serial.println("Waiting for RC link before calibrating (TX ON, sticks centered)...");
  unsigned long waitStart = millis();
  while (ibus.isFailsafe(IBUS_FAILSAFE_MS) && (millis() - waitStart < 6000)) {
    ibus.update();
  }

  if (ibus.isFailsafe(IBUS_FAILSAFE_MS)) {
    Serial.println("No RC link detected - keeping default centers (1500).");
    Serial.println("Turn the transmitter ON and reboot to calibrate to zero.");
    return;  // centers keep their 1500 defaults
  }

  Serial.println("Calibrating stick centers - DO NOT TOUCH STICKS...");

  long sumVX = 0, sumVY = 0, sumOmega = 0;
  int samples = 0;
  unsigned long calStart = millis();
  unsigned long lastSample = 0;

  while (millis() - calStart < 1000) {  // sample for 1 second
    ibus.update();
    // Throttle to ~one sample every 5ms (~200 total). The Teensy loops
    // millions of times a second, so sampling every iteration overflowed
    // the 32-bit sum (samples * ~1500 wraps past 2^31) and produced
    // garbage centers like 24/35/481 -- THAT was the leftover 0.74
    // offset. A couple hundred samples average cleanly and can't overflow.
    if (!ibus.isFailsafe(IBUS_FAILSAFE_MS) && (millis() - lastSample >= 5)) {
      lastSample = millis();
      sumVX    += ibus.channel(IBUS_CH_VX);
      sumVY    += ibus.channel(IBUS_CH_VY);
      sumOmega += ibus.channel(IBUS_CH_OMEGA);
      samples++;
    }
  }

  if (samples > 0) {
    centerVX    = sumVX    / samples;
    centerVY    = sumVY    / samples;
    centerOmega = sumOmega / samples;
  }

  // Guard against a bad calibration ever being used (see sanitizeCenter).
  centerVX    = sanitizeCenter(centerVX);
  centerVY    = sanitizeCenter(centerVY);
  centerOmega = sanitizeCenter(centerOmega);

  Serial.print("Calibrated centers -> VX: ");
  Serial.print(centerVX);
  Serial.print("  VY: ");
  Serial.print(centerVY);
  Serial.print("  Omega: ");
  Serial.println(centerOmega);
}

void setup() {
  Serial.begin(BAUD_RATE);
  ibus.begin(IBUS_BAUD);

  // Motor A pins
  pinMode(EN_A, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  // Motor B pins
  pinMode(EN_B, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);
  // Motor C pins
  pinMode(EN_C, OUTPUT);
  pinMode(IN3_C, OUTPUT);
  pinMode(IN4_C, OUTPUT);

  stopAllMotors();

  while (!Serial && millis() < 3000) {
    ; // wait briefly for USB serial on boot
  }
  Serial.println("Kiwi drive starting...");

  calibrateCenters();
}

void loop() {
  ibus.update();

  bool failsafe = ibus.isFailsafe(IBUS_FAILSAFE_MS);
  uint16_t rawEnable = ibus.channel(IBUS_CH_ENABLE);
  bool enabled = (rawEnable > IBUS_ENABLE_THRESHOLD) && !failsafe;

  if (!enabled) {
    stopAllMotors();
  } else {
    // Right stick = translation (Vx = L/R, Vy = U/D), left stick L/R =
    // rotation (Omega). Channel indices in robot_config.h now match the
    // physical sticks, so each variable reads its own channel directly.
    float Vx    = normalizedStick(IBUS_CH_VX, centerVX);
    float Vy    = normalizedStick(IBUS_CH_VY, centerVY);
    float Omega = normalizedStick(IBUS_CH_OMEGA, centerOmega);

    driveKiwi(Vx, Vy, Omega);
  }

  static unsigned long lastPrint = 0;
  if (millis() - lastPrint >= 100) {
    lastPrint = millis();
    debugPrint(enabled, failsafe);
  }
}

// ---- Joystick reading -------------------------------------------------

// Maps raw 1000-2000us iBUS value to -1.0..1.0, using a calibrated
// center (captured at boot) rather than assuming exactly IBUS_PWM_MID,
// and applying IBUS_DEADZONE around that calibrated center.
float normalizedStick(uint8_t channel, int center) {
  uint16_t raw = ibus.channel(channel);
  raw = constrain(raw, IBUS_PWM_MIN, IBUS_PWM_MAX);

  int offsetFromCenter = (int)raw - center;
  if (abs(offsetFromCenter) <= IBUS_DEADZONE) {
    return 0.0f;
  }

  float span = (offsetFromCenter > 0) ? (IBUS_PWM_MAX - center) : (center - IBUS_PWM_MIN);
  float value = (float)offsetFromCenter / span;
  return constrain(value, -1.0f, 1.0f);
}

// ---- Kinematics --------------------------------------------------------

void driveKiwi(float Vx, float Vy, float Omega) {
  // Wheel formula: -Vx*sin(theta) + Vy*cos(theta) + Omega
  float motorOnePower   = -Vx + Omega;                              // Motor C, 90 deg
  float motorTwoPower   = (Vx * 0.5f) - (Vy * SQRT3_OVER_2) + Omega; // Motor A, 210 deg
  float motorThreePower = (Vx * 0.5f) + (Vy * SQRT3_OVER_2) + Omega; // Motor B, 330 deg

  // Normalize only if any wheel command exceeds full power
  float maxPower = findAbsoluteMax(motorOnePower, motorTwoPower, motorThreePower);
  if (maxPower > 1.0f) {
    motorOnePower   /= maxPower;
    motorTwoPower   /= maxPower;
    motorThreePower /= maxPower;
  }

  // Apply physical wiring direction correction (DIR_*_CW) and the
  // per-wheel force trim (MOTOR_*_GAIN, used to ease A/B back to match the
  // slower C), each motor with its own stiction floor + breakaway kick so
  // they all start together. Motor ids: A=0, B=1, C=2.
  driveMotor(EN_C, IN3_C, IN4_C, motorOnePower   * DIR_C_CW * MOTOR_C_GAIN, MOTOR_C_MIN_PWM, MOTOR_C_KICK_PWM, 2);
  driveMotor(EN_A, IN1,   IN2,   motorTwoPower   * DIR_A_CW * MOTOR_A_GAIN, MOTOR_A_MIN_PWM, MOTOR_A_KICK_PWM, 0);
  driveMotor(EN_B, IN3,   IN4,   motorThreePower * DIR_B_CW * MOTOR_B_GAIN, MOTOR_B_MIN_PWM, MOTOR_B_KICK_PWM, 1);
}

float findAbsoluteMax(float a, float b, float c) {
  float m = fabs(a);
  if (fabs(b) > m) m = fabs(b);
  if (fabs(c) > m) m = fabs(c);
  return (m < 1.0f) ? 1.0f : m; // never divide by less than 1
}

// ---- Motor output --------------------------------------------------------

// power expected in range -1.0..1.0. minPwm is this motor's stiction
// floor (smallest PWM that turns the wheel from a standstill); kickPwm is
// its breakaway pulse level; id (0=A,1=B,2=C) keys the per-motor state
// used to fire the kick on a start-from-stop. All from robot_config.h.
void driveMotor(uint8_t enPin, uint8_t in1Pin, uint8_t in2Pin,
                float power, int minPwm, int kickPwm, uint8_t id) {
  static unsigned long kickUntil[3] = {0, 0, 0};
  static bool          wasMoving[3] = {false, false, false};

  power = constrain(power, -1.0f, 1.0f);
  float mag = fabs(power);
  bool  moving = (mag >= MOTOR_MIN_CMD);

  // Rising edge (stopped -> moving): arm the breakaway kick window so the
  // wheel gets a brief high-PWM punch to break static friction. This is
  // what makes all three wheels start together instead of C lagging.
  if (moving && !wasMoving[id]) {
    kickUntil[id] = millis() + MOTOR_KICK_MS;
  }
  wasMoving[id] = moving;

  // Treat near-zero commands as a full stop so the motor doesn't sit
  // humming at the MIN_PWM floor when the stick is basically centered.
  if (!moving) {
    digitalWrite(in1Pin, LOW);
    digitalWrite(in2Pin, LOW);
    analogWrite(enPin, 0);
    return;
  }

  if (power > 0.0f) {
    digitalWrite(in1Pin, HIGH);
    digitalWrite(in2Pin, LOW);
  } else {
    digitalWrite(in1Pin, LOW);
    digitalWrite(in2Pin, HIGH);
  }

  // Remap the command magnitude from [0..1] onto [minPwm..MOTOR_PWM_MAX]
  // so even the smallest real command clears this motor's stiction.
  int pwmValue = minPwm + (int)(mag * (MOTOR_PWM_MAX - minPwm));

  // While inside the breakaway window, hold at least kickPwm to guarantee
  // the wheel actually breaks free from a dead stop.
  if (millis() < kickUntil[id] && pwmValue < kickPwm) {
    pwmValue = kickPwm;
  }

  pwmValue = constrain(pwmValue, 0, MOTOR_PWM_MAX);
  analogWrite(enPin, pwmValue);
}

void stopAllMotors() {
  driveMotor(EN_A, IN1,   IN2,   0.0f, MOTOR_A_MIN_PWM, MOTOR_A_KICK_PWM, 0);
  driveMotor(EN_B, IN3,   IN4,   0.0f, MOTOR_B_MIN_PWM, MOTOR_B_KICK_PWM, 1);
  driveMotor(EN_C, IN3_C, IN4_C, 0.0f, MOTOR_C_MIN_PWM, MOTOR_C_KICK_PWM, 2);
}

// ---- Debug ---------------------------------------------------------------

void debugPrint(bool enabled, bool failsafe) {
  if (failsafe) {
    Serial.println("!! FAILSAFE - no valid iBUS frame recently - motors stopped !!");
    return;
  }

  float Vx    = normalizedStick(IBUS_CH_VX, centerVX);
  float Vy    = normalizedStick(IBUS_CH_VY, centerVY);
  float Omega = normalizedStick(IBUS_CH_OMEGA, centerOmega);

  Serial.print("ENABLE: ");
  Serial.print(enabled ? "ON " : "OFF");
  Serial.print("  Vx: ");
  Serial.print(Vx, 2);
  Serial.print("  Vy: ");
  Serial.print(Vy, 2);
  Serial.print("  Omega: ");
  Serial.print(Omega, 2);

  // RAW iBUS values + calibrated centers, to diagnose link problems.
  // With a good link and centered sticks each raw should read ~1500 and
  // sit close to its center. If they're all pinned at some other value
  // (e.g. ~1870) the transmitter isn't really linked / bound.
  Serial.print("   | raw  VX:");
  Serial.print(ibus.channel(IBUS_CH_VX));
  Serial.print(" VY:");
  Serial.print(ibus.channel(IBUS_CH_VY));
  Serial.print(" OM:");
  Serial.print(ibus.channel(IBUS_CH_OMEGA));
  Serial.print(" EN:");
  Serial.print(ibus.channel(IBUS_CH_ENABLE));
  Serial.print("   centers VX:");
  Serial.print(centerVX);
  Serial.print(" VY:");
  Serial.print(centerVY);
  Serial.print(" OM:");
  Serial.println(centerOmega);
}
