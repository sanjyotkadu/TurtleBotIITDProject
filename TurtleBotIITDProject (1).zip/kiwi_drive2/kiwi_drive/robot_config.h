#ifndef ROBOT_CONFIG_H
#define ROBOT_CONFIG_H

// ============================================================
// robot_config.h — TurtleBot IITD Central Configuration
//
// All pin assignments and robot parameters are defined here.
// Include in any sketch with: #include "robot_config.h"
// Change any value here and it updates across the whole project.
// ============================================================

// ------------------------------------------------------------
// ENCODER — Counts Per Revolution (CPR)
// Measured by manually rotating each wheel one full revolution.
// All motors ~2115 counts/rev. Offset: ±10 counts.
// ------------------------------------------------------------
#define MOTOR_A_CPR      2115
#define MOTOR_B_CPR      2115
#define MOTOR_C_CPR      2115
#define ENCODER_OFFSET   10     // ±10 counts tolerance per revolution

// ------------------------------------------------------------
// WHEEL GEOMETRY (Omni Wheel)
// Screw-to-screw (hub diameter)      : 35.0mm
// Roller-to-roller (rolling diameter): 37.3mm  ← used for calculations
// ------------------------------------------------------------
#define WHEEL_DIAMETER_MM       37.3   // roller-to-roller
#define WHEEL_CIRCUMFERENCE_MM  (WHEEL_DIAMETER_MM * 3.14159265)

// Distance per encoder count = 117.1mm / 2115 = ~0.0554mm
#define MOTOR_A_MM_PER_COUNT  (WHEEL_CIRCUMFERENCE_MM / MOTOR_A_CPR)
#define MOTOR_B_MM_PER_COUNT  (WHEEL_CIRCUMFERENCE_MM / MOTOR_B_CPR)
#define MOTOR_C_MM_PER_COUNT  (WHEEL_CIRCUMFERENCE_MM / MOTOR_C_CPR)

// ------------------------------------------------------------
// ROBOT CHASSIS GEOMETRY
// Chassis plate diameter             : 162.0mm (16.2cm)
// Chassis plate radius               : 81.0mm
// Wheel protrusion beyond chassis    : 3.0mm
// Robot radius (center to wheel)     : 84.0mm
// ------------------------------------------------------------
#define CHASSIS_DIAMETER_MM    162.0
#define CHASSIS_RADIUS_MM       81.0
#define WHEEL_PROTRUSION_MM      3.0
#define ROBOT_RADIUS_MM         84.0

// ------------------------------------------------------------
// ENCODER COUNTS FOR EXACTLY 360° ROTATION
// Measured empirically on flat floor.
// ------------------------------------------------------------
#define COUNTS_360_A  7566
#define COUNTS_360_B  7813
#define COUNTS_360_C  7634

// ------------------------------------------------------------
// ROTATION DIRECTION FOR CLOCKWISE TURN
// Confirmed via direction test: all motors BWD = CW
// +1 = forward = CW,  -1 = backward = CW
// ------------------------------------------------------------
#define DIR_A_CW  -1
#define DIR_B_CW  -1
#define DIR_C_CW  -1

// ------------------------------------------------------------
// WHEEL LAYOUT (top view)
//         FRONT
//           C (90°)
//          / \
//         /   \
//        A     B
//    (210°)   (330°)
// ------------------------------------------------------------
#define MOTOR_FRONT       'C'
#define MOTOR_BACK_LEFT   'A'
#define MOTOR_BACK_RIGHT  'B'

// ------------------------------------------------------------
// MOTOR DRIVER 1 — Motors A & B (L298N)
// ------------------------------------------------------------
#define EN_A   9    // Motor A PWM speed ..........MOT 2
#define IN1    8    // Motor A direction pin 1
#define IN2    6    // Motor A direction pin 2
#define EN_B   2    // Motor B PWM speed..........MOT 1
#define IN3    4    // Motor B direction pin 1
#define IN4    3    // Motor B direction pin 2

// ------------------------------------------------------------
// MOTOR DRIVER 2 — Motor C (L298N)
// ------------------------------------------------------------
#define EN_C   5    // Motor C PWM speed.........MOT 3
#define IN3_C  10   // Motor C direction pin 1
#define IN4_C  11   // Motor C direction pin 2

// ------------------------------------------------------------
// ENCODER PINS (VCC = 3.3V — Teensy 4.1 NOT 5V tolerant)
// ------------------------------------------------------------
#define ENC_A1  15  // Motor A C1 (interrupt)
#define ENC_A2  16  // Motor A C2 (direction)
#define ENC_B1  12  // Motor B C1 (interrupt)
#define ENC_B2  14  // Motor B C2 (direction)
#define ENC_C1  17  // Motor C C1 (interrupt)
#define ENC_C2  18  // Motor C C2 (direction)

// ------------------------------------------------------------
// SERIAL
// ------------------------------------------------------------
#define BAUD_RATE  115200

// ------------------------------------------------------------
// FLYSKY FS-iA6B RECEIVER — iBUS PROTOCOL
// iBUS is a single-wire digital serial link (all channels
// multiplexed), so we use one free hardware serial port instead
// of burning a pin per channel like classic PWM receivers need.
//
// Wiring:
//   FS-iA6B "iBUS" pad  -> Teensy 4.1 pin 0 (RX1)
//   FS-iA6B GND          -> Teensy GND
//   FS-iA6B VCC          -> Teensy 3.3V or 5V per receiver spec
//   (Teensy pin 1 / TX1 is unused — iBUS servo output is RX only)
//
// Pins 0/1 were the only hardware-serial-capable pins not
// already committed to motors/encoders in this config.
// ------------------------------------------------------------
#define IBUS_SERIAL             Serial1   // uses pins 0(RX1)/1(TX1)
#define IBUS_BAUD               115200
#define IBUS_NUM_CHANNELS       14
#define IBUS_FAILSAFE_MS        500       // stop motors if no valid frame in this long

// Channel index (0-based) -> stick function
// Standard FlySky i6/i6X mapping: CH1=Roll/Aileron, CH2=Pitch/Elevator,
// CH3=Throttle, CH4=Yaw/Rudder, CH5/CH6=aux switches (SWA/SWB/SWC/SWD)
//
// Indices below were VERIFIED on this transmitter by watching raw channel
// values while moving each stick, so every macro names the stick it truly
// reads (no swap needed in the sketch anymore):
//   Vx    <- CH4 (index 3) = RIGHT stick L/R  -> strafe left/right
//   Vy    <- CH2 (index 1) = RIGHT stick U/D  -> forward/back
//   Omega <- CH1 (index 0) = LEFT  stick L/R  -> rotation / spin
#define IBUS_CH_VX              3   // CH4 — right stick L/R  -> strafe (x)
#define IBUS_CH_VY              1   // CH2 — right stick U/D  -> forward/back (y)
#define IBUS_CH_OMEGA           0   // CH1 — left  stick L/R  -> rotation (omega)
#define IBUS_CH_ENABLE          4   // CH5 — 2/3-pos switch   -> motor enable / kill switch

// Raw PWM range iBUS reports per channel (microseconds, FlySky standard)
#define IBUS_PWM_MIN            1000
#define IBUS_PWM_MID            1500
#define IBUS_PWM_MAX            2000
#define IBUS_DEADZONE           50      // +/- counts around center ignored (stick drift / near-neutral)
#define IBUS_ENABLE_THRESHOLD   1500    // switch HIGH position must exceed this to enable

// ------------------------------------------------------------
// RC DRIVE TUNING
// ------------------------------------------------------------
#define MAX_LINEAR_SPEED_MM_S    300.0   // full-stick translation speed
#define MAX_ANGULAR_SPEED_RAD_S  2.0     // full-stick rotation speed
#define MOTOR_PWM_MAX            255     // analogWrite ceiling

// ------------------------------------------------------------
// STICTION / MINIMUM-DRIVE COMPENSATION
// Each motor needs a minimum PWM before its wheel breaks free from a
// standstill; below it the motor only hums. This was the cause of the
// strafe-curve: the front wheel C needs MORE PWM to start than A/B, so
// at low stick C sat still while A/B already crept -> the robot yawed.
// Any nonzero wheel command is remapped into [MIN_PWM .. MOTOR_PWM_MAX]
// so every commanded wheel starts turning together.
//
// TUNE ON THE ROBOT: with the wheels off the ground, raise each value
// until that wheel *just* starts turning at the smallest stick input.
// C is set highest here because it was the slowest to break away.
// ------------------------------------------------------------
#define MOTOR_A_MIN_PWM          45
#define MOTOR_B_MIN_PWM          45
#define MOTOR_C_MIN_PWM          60

// Commands with |power| below this count as a full stop, so the motors
// don't hum at the MIN_PWM floor on tiny residual (near-center) commands.
#define MOTOR_MIN_CMD            0.02f

// ------------------------------------------------------------
// BREAKAWAY KICK (stiction pulse)
// When a wheel starts from a standstill it gets a brief high-PWM pulse to
// break static friction, then settles to the commanded level. This makes
// all three wheels start in the SAME instant -- without it the front
// wheel C broke free later than A/B, so the robot yawed at the start of a
// strafe. C is kicked hardest because it is the slowest to move.
//
// TUNE ON THE ROBOT: raise a motor's KICK_PWM until it starts crisply
// from a dead stop; raise KICK_MS if it needs longer to break free. To
// effectively disable the kick for a motor, set its KICK_PWM = MIN_PWM.
// ------------------------------------------------------------
#define MOTOR_A_KICK_PWM         120
#define MOTOR_B_KICK_PWM         120
#define MOTOR_C_KICK_PWM         200
#define MOTOR_KICK_MS            50    // duration of the breakaway pulse (ms)

// ------------------------------------------------------------
// PER-WHEEL OUTPUT GAIN (force trim)
// Scales each wheel's final output (0.0..1.0) to balance wheels that make
// different force for the same PWM. Here A and B are eased BACK so they
// don't out-drive the slower front wheel C during a strafe -- the
// alternative to kicking C harder. 1.0 = full power, lower = weaker.
//
// TUNE ON THE ROBOT:
//   * If the strafe curves the SAME way at ALL speeds -> steady-state
//     mismatch: lower MOTOR_A_GAIN and MOTOR_B_GAIN together (e.g. 0.85,
//     0.80...) until it tracks straight.
//   * If it only curves at the START and then straightens -> that's
//     stiction, not force: leave gains at 1.0 and use the breakaway kick.
// NOTE: trimming A/B also lowers top strafe speed slightly, and since
// spin uses all three wheels, large trims can add a little drift to spin.
// ------------------------------------------------------------
#define MOTOR_A_GAIN             0.85f
#define MOTOR_B_GAIN             0.85f
#define MOTOR_C_GAIN             1.00f

// Wheel mounting angles (deg), standard math convention:
// 0 deg = robot's right (+x), 90 deg = front (+y), CCW positive.
// Matches the physical layout diagram above (C front, A back-left, B back-right).
#define WHEEL_A_ANGLE_DEG   210.0
#define WHEEL_B_ANGLE_DEG   330.0
#define WHEEL_C_ANGLE_DEG    90.0

// ------------------------------------------------------------
// QUICK REFERENCE — Pin Allocation Summary
//
//  Pin  2  → EN_B   (Motor B PWM enable)
//  Pin  3  → IN4    (Motor B direction)
//  Pin  4  → IN3    (Motor B direction)
//  Pin  5  → EN_C   (Motor C PWM enable)
//  Pin  6  → IN2    (Motor A direction)
//  Pin  8  → IN1    (Motor A direction)
//  Pin  9  → EN_A   (Motor A PWM enable)
//  Pin 10  → IN3_C  (Motor C direction)
//  Pin 11  → IN4_C  (Motor C direction)
//  Pin 12  → ENC_B1 (Motor B encoder C1 — interrupt)
//  Pin 14  → ENC_B2 (Motor B encoder C2 — direction)
//  Pin 15  → ENC_A1 (Motor A encoder C1 — interrupt)
//  Pin 16  → ENC_A2 (Motor A encoder C2 — direction)
//  Pin 17  → ENC_C1 (Motor C encoder C1 — interrupt)
//  Pin 18  → ENC_C2 (Motor C encoder C2 — direction)
//
//  3.3V → Encoder VCC (all 3 motors)
//  5V   → L298N logic supply (VSS)
//  12V  → L298N motor supply (VS) [external]
//  GND  → Common ground (Teensy + L298N + encoders)
// ------------------------------------------------------------

#endif // ROBOT_CONFIG_H