#include "obstacleAvoidRotate.h"
#include "robot_config.h"
#include "navigation.h"
#include "motorControl.h"
#include "encoder.h"
#include "imu.h"
#include "statusIndicator.h"
#include "PID.h"
#include <math.h>

// ---------------- ultrasonic ----------------
// Same approach/timing as obstacleAvoid.cpp's pingQuickCm()/pingClosestCm()
// (file-local `static`, so no link conflict even with that file compiled
// into the same sketch) - see that file for the reasoning behind
// OBSTACLE_PING_GAP_MS between samples.

static float pingQuickCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  unsigned long echoUs = pulseIn(ECHO_PIN, HIGH, SCAN_CHECK_TIMEOUT_US);
  if (echoUs == 0) return (float)SONAR_MAX_RANGE_CM;

  float cm = (echoUs * 0.0343f) / 2.0f;
  if (cm < SONAR_MIN_RANGE_CM) return 0.0f; // too close - treat as blocked
  return cm;
}

static float pingClosestCm(int samples) {
  float closest = (float)SONAR_MAX_RANGE_CM;
  for (int i = 0; i < samples; i++) {
    float cm = pingQuickCm();
    if (cm < closest) closest = cm;
    if (i < samples - 1) delay(OBSTACLE_PING_GAP_MS);
  }
  return closest;
}

// ---------------- obstacle LED alert ----------------

static void ledSet(bool on) {
  digitalWrite(OBSTACLE_LED_PIN, on ? HIGH : LOW);
}

// Polls imu_update() during the blink - see obstacleAvoid.cpp's
// ledAlertBurst() for why this matters (IMU_TIMEOUT_MS is only 200ms, and
// this runs right before navDriveStraight()'s own imu_healthy() check in
// the EMERGENCY tier below).
static void ledAlertBurst() {
  for (int i = 0; i < OBSTACLE_ALERT_BLINKS; i++) {
    ledSet(true);  delay(OBSTACLE_ALERT_BLINK_MS); imu_update();
    ledSet(false); delay(OBSTACLE_ALERT_BLINK_MS); imu_update();
  }
}

// ---------------- public API ----------------

void avoidRotateInit() {
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  digitalWrite(TRIG_PIN, LOW);

  pinMode(OBSTACLE_LED_PIN, OUTPUT);
  digitalWrite(OBSTACLE_LED_PIN, LOW);

  Serial.println("[AVOID] rotate-to-scan obstacle avoidance ready (no servo).");
}

void avoidRotateClearAlert() {
  ledSet(false);
  // Only ever called from within a running nav sequence, same reasoning
  // as obstacleAvoid.cpp's obstacleClearAlert() - safe to drop back to
  // the "running normally" status pattern here.
  statusIndicatorSetState(STATUS_NAV_RUNNING);
}

// Drives the whole leg as one continuous motion, single heading-hold lock,
// checking the sonar in-line every OBSTACLE_CHECK_CHUNK_MM of actual
// progress without stopping between checks - identical shape to
// obstacleAvoid.cpp's (already-fixed) driveStraightWithObstacleCheck(),
// just with no servo anywhere in it: the sensor is fixed to the chassis,
// so "checking ahead" never needs to re-aim anything.
RotateDriveResult driveStraightWithRotateCheck(float distanceMM, float speed, float &distanceDrivenMM) {
  distanceDrivenMM = 0.0f;

  if (!imu_healthy()) {
    Serial.println("[AVOID] IMU not healthy - aborting straight leg.");
    return ROTATE_DRIVE_ABORTED;
  }

  imu_resetHeadingHold();   // latch ONCE for the whole leg

  long  startA = encoderCount('A');
  long  startB = encoderCount('B');
  float drivenBeforeThisStretch = 0.0f;   // carries progress across an emergency-backup re-baseline
  float distanceAtLastCheck     = 0.0f;
  unsigned long lastRangePrint  = 0;

  while (true) {
    if (navShouldAbort()) {
      stopAllMotors();
      ledSet(false);
      return ROTATE_DRIVE_ABORTED;
    }
    imu_update();
    statusIndicatorUpdate();

    float traveledThisStretch = navEncoderDistanceMM(startA, startB);
    distanceDrivenMM = drivenBeforeThisStretch + traveledThisStretch;
    if (distanceDrivenMM >= distanceMM) break;

    if (traveledThisStretch - distanceAtLastCheck >= OBSTACLE_CHECK_CHUNK_MM) {
      distanceAtLastCheck = traveledThisStretch;

      float cm = pingClosestCm(OBSTACLE_CHECK_SAMPLES);

      if (millis() - lastRangePrint >= 250) {
        lastRangePrint = millis();
        Serial.print("[AVOID] range: ");
        Serial.print(cm, 1);
        Serial.println(" cm");
      }

      if (cm <= OBSTACLE_EMERGENCY_CM) {
        // Too close to trust a turn-in-place - back straight off instead,
        // then keep trying for the same target from the new position.
        stopAllMotors();
        ledAlertBurst();
        ledSet(true);
        statusIndicatorSetState(STATUS_OBSTACLE);
        Serial.print("[AVOID] EMERGENCY - obstacle within ");
        Serial.print(OBSTACLE_EMERGENCY_CM, 0);
        Serial.println(" cm, too close to turn - backing up.");
        // stopAllMotors() just above forces PWM to 0 directly - it does
        // NOT go through pidUpdate(), so each wheel's PID still has
        // whatever (possibly wound-up) integral term it had while
        // actively driving forward a moment ago. Without clearing it
        // here, that stale term bleeds into the backup maneuver's power.
        pidResetAll();
        if (!navDriveStraight(OBSTACLE_BACKUP_MM, -OBSTACLE_BACKUP_SPEED)) { ledSet(false); return ROTATE_DRIVE_ABORTED; }
        if (!navSettle(NAV_SETTLE_MS))                                    { ledSet(false); return ROTATE_DRIVE_ABORTED; }

        imu_resetHeadingHold();
        startA = encoderCount('A');
        startB = encoderCount('B');
        drivenBeforeThisStretch = distanceDrivenMM;
        distanceAtLastCheck = 0.0f;
        continue;
      }

      if (cm <= OBSTACLE_TRIGGER_CM) {
        // A new direction is needed - navRunWaypointSequence() calls
        // avoidFindOpeningByRotation() next.
        stopAllMotors();
        ledAlertBurst();
        ledSet(true);
        statusIndicatorSetState(STATUS_OBSTACLE);
        return ROTATE_DRIVE_BLOCKED;
      }

      if (cm <= OBSTACLE_ALERT_CM) {
        Serial.print("[AVOID] alert: obstacle ");
        Serial.print(cm, 1);
        Serial.println(" cm ahead");
        ledSet(true); delay(60); ledSet(false);
      }
    }

    float omega = imu_applyHeadingHold(0.0f);
    navDrive(0.0f, speed, omega);
  }

  stopAllMotors();
  ledSet(false);
  statusIndicatorSetState(STATUS_NAV_RUNNING);
  return ROTATE_DRIVE_REACHED;
}

// ---------------- rotate-to-scan ----------------

enum ScanStepOutcome { SCAN_FOUND, SCAN_NOT_FOUND, SCAN_ABORTED };

// Turns in ROTATE_SCAN_STEP_DEG steps (sign +1 = CCW/left, -1 = CW/right,
// matching navTurn()'s CCW+ convention), stopping to take a confirmed
// reading after each step, up to ROTATE_SCAN_MAX_DEG total. Reports how
// many steps it actually took in stepsTaken (== the full step count on
// SCAN_NOT_FOUND; fewer on SCAN_FOUND/SCAN_ABORTED) so the caller knows
// exactly how far to turn back.
//
// On SCAN_FOUND the chassis is left facing the clear heading (deliberate
// - see obstacleAvoidRotate.h). On SCAN_NOT_FOUND it's left at the far
// end of this search, ROTATE_SCAN_MAX_DEG from wherever the caller was
// pointed when it called this - the caller turns back using stepsTaken.
// On SCAN_ABORTED it's left wherever navTurn() stopped; the caller must
// not move it further (an abort means E-stop/disarm/failsafe took over).
static ScanStepOutcome scanOneSide(int sign, int &stepsTaken) {
  stepsTaken = 0;
  int maxSteps = (int)(ROTATE_SCAN_MAX_DEG / ROTATE_SCAN_STEP_DEG + 0.5f);

  while (stepsTaken < maxSteps) {
    if (!navTurn((float)sign * ROTATE_SCAN_STEP_DEG)) return SCAN_ABORTED;
    stepsTaken++;

    float cm = pingClosestCm(OBSTACLE_CHECK_SAMPLES);
    bool clear = (cm >= SCAN_CLEAR_CM);

    Serial.print("[AVOID]   check ");
    Serial.print((float)sign * stepsTaken * ROTATE_SCAN_STEP_DEG, 0);
    Serial.print(" deg -> ");
    Serial.println(clear ? "clear" : "blocked");

    if (clear) return SCAN_FOUND;
  }
  return SCAN_NOT_FOUND;
}

bool avoidFindOpeningByRotation() {
  // driveStraightWithRotateCheck() just hard-stopped via stopAllMotors()
  // (bypasses pidUpdate(), so each wheel's PID integral is still whatever
  // it was while actively driving forward) - reset it now, before the
  // first navTurn() below, or that stale forward-drive integral blends
  // extra forward power into what should be a clean turn-in-place. This
  // is the ONLY reset needed for the whole scan: navTurn() itself settles
  // to a zero/idle command (and PID.cpp's own deadband logic clears the
  // integrator on going idle) before it returns, so each subsequent
  // navTurn() call in scanOneSide() below already starts clean.
  pidResetAll();

  int steps = 0;

  Serial.println("[AVOID] rotating LEFT to scan...");
  ScanStepOutcome left = scanOneSide(+1, steps);
  if (left == SCAN_FOUND)   return true;
  if (left == SCAN_ABORTED) return false;

  Serial.println("[AVOID] LEFT blocked within range - returning to start, scanning RIGHT...");
  if (!navTurn(-1.0f * steps * ROTATE_SCAN_STEP_DEG)) return false;

  ScanStepOutcome right = scanOneSide(-1, steps);
  if (right == SCAN_FOUND)   return true;
  if (right == SCAN_ABORTED) return false;

  Serial.println("[AVOID] blocked on both sides within range - returning to start heading.");
  navTurn(1.0f * steps * ROTATE_SCAN_STEP_DEG);   // best-effort - nothing more to do if this aborts too
  return false;
}
