#ifndef OBSTACLE_AVOID_ROTATE_H
#define OBSTACLE_AVOID_ROTATE_H

#include <Arduino.h>

// ============================================================
// obstacleAvoidRotate.h — no-servo alternative to obstacleAvoid.h: the
// front-facing HC-SR04 is fixed to the chassis (SERVO_PIN/Servo.h are
// never touched by this file), and "looking left/right" is done by
// physically turning the whole robot in place with navTurn() instead of
// panning a servo. Same public shape as obstacleAvoid.h (drive-with-check
// + find-an-opening) and the SAME tiered thresholds from robot_config.h
// (OBSTACLE_EMERGENCY_CM/TRIGGER_CM/ALERT_CM, SCAN_CLEAR_CM) - only how
// the sensor gets aimed is different (see ROTATE_SCAN_STEP_DEG/MAX_DEG).
//
// obstacleAvoid.h/.cpp are left in the project untouched (not deleted -
// kept as a reference/fallback) but nothing calls into them anymore;
// main.ino/navigation.cpp call this file's functions instead. Function
// and type names here are deliberately distinct from obstacleAvoid.h's
// (avoidRotate*/RotateDriveResult vs obstacleAvoid*/ObstacleDriveResult)
// so both files can be compiled into the same sketch with zero symbol
// clashes even though only one is actually wired up.
//
// Bring up with avoidRotateInit() once from setup(), after imu_init() and
// motorsInit() - same spot obstacleAvoidInit() used to go.
// ============================================================

// Arms the ultrasonic pins and the obstacle-present indicator LED. Unlike
// obstacleAvoidInit(), this never touches SERVO_PIN/Servo - there is no
// servo in this module at all. Call once from setup().
void avoidRotateInit();

// Turns the obstacle-present indicator LED (OBSTACLE_LED_PIN) off. See
// obstacleAvoid.h's obstacleClearAlert() - same role, same LED, just a
// distinct name to avoid a symbol clash with that file.
void avoidRotateClearAlert();

enum RotateDriveResult {
  ROTATE_DRIVE_REACHED,  // the full distanceMM was covered
  ROTATE_DRIVE_BLOCKED,  // stopped early - something within OBSTACLE_TRIGGER_CM, caller decides what's next
  ROTATE_DRIVE_ABORTED,  // navShouldAbort() tripped (disarm/E-stop/failsafe/nav trigger released)
};

// Drives straight (current heading held, same as navDriveStraight()) up
// to distanceMM, checking the front-facing HC-SR04 every
// OBSTACLE_CHECK_CHUNK_MM without stopping between checks - identical
// tiered reaction (EMERGENCY/TRIGGER/ALERT) to obstacleAvoid.h's
// driveStraightWithObstacleCheck(), just with no servo to re-center
// anywhere in this one since the sensor never moves relative to the
// chassis. distanceDrivenMM is always set to how far it actually got.
RotateDriveResult driveStraightWithRotateCheck(float distanceMM, float speed, float &distanceDrivenMM);

// Searches for an opening by physically turning the CHASSIS in
// ROTATE_SCAN_STEP_DEG steps (via navTurn()) - LEFT first up to
// ROTATE_SCAN_MAX_DEG, then, if still blocked, back to the starting
// heading and RIGHT up to ROTATE_SCAN_MAX_DEG - stopping at each step to
// take a confirmed reading (same "closest of OBSTACLE_CHECK_SAMPLES
// pings, must clear SCAN_CLEAR_CM" test the servo version uses).
//
// On success, the chassis is LEFT FACING THE OPENING (not turned back to
// where it started) - deliberately, so the caller doesn't have to turn
// there a second time: unlike obstacleAvoid.h's obstacleFindOpening(),
// there's no outRelativeDegCCW to hand back, because the caller doesn't
// need one - navRunWaypointSequence() (navigation.cpp) just reads
// imu_headingRad() directly once this returns true and places the detour
// waypoint straight ahead along it, and the very next navTurn() in its
// loop naturally comes out near 0 deg since the chassis is already
// pointed the right way.
//
// On failure (blocked within ROTATE_SCAN_MAX_DEG on both sides), the
// chassis is turned back to the heading it had when this was called
// before returning false, so a caller that waits and calls this again
// (see navRunWaypointSequence()'s "blocked on all sides" retry loop)
// starts each retry from the same reference heading instead of drifting
// further off course with every failed attempt.
bool avoidFindOpeningByRotation();

#endif // OBSTACLE_AVOID_ROTATE_H
